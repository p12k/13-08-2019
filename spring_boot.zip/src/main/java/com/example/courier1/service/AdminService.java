package com.example.courier1.service;

import com.example.courier1.bean.*;

public interface AdminService {
	Boolean getAdmin(Admin admin);
	Admin createAdmin(Admin admin);
}
