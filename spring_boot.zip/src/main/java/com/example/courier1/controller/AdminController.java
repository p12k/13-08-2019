package com.example.courier1.controller;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.courier1.bean.Admin;
import com.example.courier1.bean.Couriers;
import com.example.courier1.service.AdminService;
import com.example.courier1.Couriers.dao.CouriersDao;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private AdminService service;
	
	@PostMapping("/login")
	@CrossOrigin(origins = "http://localhost:4200")
	public Boolean getAdmin(@RequestBody Admin admin){
		System.out.println("REceived request");
		return service.getAdmin(admin);
	}
	
	@PostMapping("add")
	@CrossOrigin(origins = "http://localhost:4200")
	public Admin getAdmin2(@RequestBody Admin admin){
		System.out.println("REceived request");
		return service.createAdmin(admin);
	}
}